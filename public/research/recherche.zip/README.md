# fin — moteur de recherche

Node.js 24. Aucune dépendance externe pour les calculs.

    npm install
    npm test
    npm run screen
    npm run collect -- --output output/snapshot.json

Le protocole complet est public/research/protocole.md.
La référence indépendante : python3 public/research/analyse-reference.py.

Relevés datés dans snapshot.json. La référence de test du 16 octobre est conservée séparément. Aucun avantage prédictif validé.
